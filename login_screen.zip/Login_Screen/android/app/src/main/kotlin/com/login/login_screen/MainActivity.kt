package com.login.login_screen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
